import os
import sys

from numpy.distutils.core import setup, Extension

def configuration(parent_package='',top_path=None):
    from numpy.distutils.misc_util import Configuration
    confgr = Configuration('samplerate', parent_package, top_path)

    confgr.add_extension('_samplerate', [
        '_samplerate.c',
        'src/samplerate.c',
        'src/src_linear.c',
        'src/src_sinc.c',
        'src/src_zoh.c'], include_dirs=['src'])
    confgr.add_data_dir('tests')

    return confgr

if __name__ == "__main__":
    from numpy.distutils.core import setup
    setup(configuration=configuration)
